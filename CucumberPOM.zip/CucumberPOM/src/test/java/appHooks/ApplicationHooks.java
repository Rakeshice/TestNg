package appHooks;


import java.util.Properties;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import driverFactory.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.ConfigReader;

public class ApplicationHooks {

	private DriverFactory driverfactory;
	private ConfigReader configreader;
	private Properties prop;
	private WebDriver driver;

	@Before(order = 0)
	public void getProperty() {
		configreader = new ConfigReader();
		prop = configreader.configreader();
	}

	@Before(order = 1)
	public void lunchBrowser() {
		prop=configreader.configreader();
		String browserName = prop.getProperty("browser");
		System.out.println("Browser is:"+browserName);
		driverfactory = new DriverFactory();
		driver=driverfactory.driverInitialization(browserName);

	}
	
	@After(order=1)
	public void getScreenshot(Scenario sc)
	{
		if(sc.isFailed())
		{
			String scenarioName= sc.getName().replaceAll(" ","_");
			TakesScreenshot ts= (TakesScreenshot)driver;
			byte[] screenshotSRC= ts.getScreenshotAs(OutputType.BYTES);
			sc.attach(screenshotSRC, "image/png", scenarioName);
		}
		
	}
	@After(order=0)
	public void quitBrowser()
	{
		driver.quit();
	}
}
