package stepDefinations;

import org.junit.Assert;

import driverFactory.DriverFactory;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import pages.LoginPage;

public class loginStepDefination {
	
	private LoginPage lp = new LoginPage(DriverFactory.getDriver());
	private static String ActulaloginPageTitle;
	
	@Given("^User is on login page$")
	public void user_is_on_login_page() {
		DriverFactory.getDriver().get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
	}

    @Then("^user gets the title of the page$")
    public void user_gets_the_title_of_the_page()  {
    	ActulaloginPageTitle=lp.getPageTitle();
    }
    @When("^user enter UserName \"([^\"]*)\"$")
    public void user_enter_username_something(String un)  {
        lp.enterUserName(un);
     }

    @And("^Page Tilte should be \"([^\"]*)\"$")
    public void page_tilte_should_be_something(String expected)  {
		Assert.assertEquals(ActulaloginPageTitle, expected);
    }


    @And("^user enter Password \"([^\"]*)\"$")
    public void user_enter_password_some(String pwd)  {
        lp.enterPassword(pwd);
    }

    @And("^user clicks on Login button$")
    public void user_clicks_on_login_button()  {
       lp.clickOnLogin();
    }
 
    @Then("^\"([^\"]*)\" exists$")
    public void something_exists(String forgetPasswordLink)  {
       Assert.assertTrue(lp.isForgotPasswordLinkExists());
    }
    }

