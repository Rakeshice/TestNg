package stepDefinations;

import java.util.List;
import java.util.Map;

import org.junit.Assert;

import driverFactory.DriverFactory;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AccountsPage;
import pages.LoginPage;

public class AccountsStepDefination {
	private LoginPage lp= new LoginPage(DriverFactory.getDriver());
	private AccountsPage ap;
	
	@Given("user is already logged into the application using below credentials")
	public void user_is_already_logged_into_the_application_using_below_credentials(DataTable dataTable) {
	 
	List<Map<String,String>> credList=dataTable.asMaps();
	String userName = credList.get(0).get("UserName");
	String userPass = credList.get(0).get("Password");
	DriverFactory.getDriver().get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
		ap= lp.login(userName, userPass);
	}

	@Given("user is on Accounts page")
	public void user_is_on_accounts_page() {
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("user is gets account section")
	public void user_is_gets_account_section(DataTable dataTable) {
	   
		List<String> actualData= dataTable.asList();
		List<String> expectedData=ap.accountSectionLists();
		Assert.assertTrue(actualData.containsAll(expectedData));
	}


@When("user gets the tilte of page")
public void user_gets_the_tilte_of_page() {
    // Write code here that turns the phrase above into concrete actions
  
}

@Then("page titile should be {string}")
public void page_titile_should_be(String string) {
    // Write code here that turns the phrase above into concrete actions
  
}

	@Then("account section count should be {int}")
	public void account_section_count_should_be(Integer expected) {
		
	   Assert.assertTrue(ap.accountSectionCount()==expected); 
	}
}
