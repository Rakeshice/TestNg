package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class AccountsPage {

	
	
	private WebDriver driver;
	private By accountSections = By.cssSelector("div#center_column");
	 public AccountsPage(WebDriver driver)
	 {
		 this.driver= driver;
	 }
	
public int accountSectionCount()
{
	return driver.findElements(accountSections).size();
}

public List<String> accountSectionLists()
{
	List<String> accountheadertext = new ArrayList<String>();
	List<WebElement> accountSectionElemnets = driver.findElements(accountSections); 
	for(WebElement e:accountSectionElemnets )
	{
		accountheadertext.add(e.getText());
	}
	return accountheadertext;
	
}
}
