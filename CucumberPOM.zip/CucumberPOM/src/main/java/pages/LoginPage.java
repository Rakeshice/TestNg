package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	private WebDriver driver;

	// Locators

	private By emailId = By.id("email");
	private By password = By.id("passwd");
	private By submitButton = By.id("SubmitLogin");
	private By forgotpasswordlink = By.linkText("Forgot your password?");

	// Constructors
	public LoginPage(WebDriver driver) {

		this.driver = driver;
	}

	// Actions
	public String getPageTitle() {
		return driver.getTitle();
	}

	public boolean isForgotPasswordLinkExists()
	{
		
		return driver.findElement(forgotpasswordlink).isDisplayed();
	}

	public void enterUserName(String un) {
		driver.findElement(emailId).sendKeys(un);		
	}
	public void enterPassword(String pwd) {
		driver.findElement(password).sendKeys(pwd);		
	}
	public void clickOnLogin() {
		driver.findElement(submitButton).click();	
		
	}
	
	public AccountsPage login(String un, String pwd) {
		driver.findElement(emailId).sendKeys(un);
		driver.findElement(password).sendKeys(pwd);		
		driver.findElement(submitButton).click();	
return new AccountsPage(driver);
	}
}


