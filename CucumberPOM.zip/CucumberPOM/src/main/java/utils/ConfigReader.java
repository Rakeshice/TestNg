package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {

	FileInputStream fis;
	Properties prop;

	public Properties configreader() {
		prop = new Properties();
		try {
			fis = new FileInputStream("C:\\Users\\Rakes\\eclipse-workspace\\CucumberPOM\\src\\test\\resources\\config\\config.properties");
			prop.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return prop;
	}
}
