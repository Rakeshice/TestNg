package utils;

public class Constants {

}
