package com.crm.qa.pages;

import java.io.FileNotFoundException;

import com.crm.qa.base.TestBase;

public class TasksPage extends TestBase{

	public TasksPage() throws FileNotFoundException {
		//super();
		// TODO Auto-generated constructor stub
	}
	
	

}
